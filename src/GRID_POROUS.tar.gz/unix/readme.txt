/bin
Cont�m arquivos j� compilados pronto para serem executados (com dependecias)

/dependencias
Cont�m arquivos necess�rios para compilar ou executar

/src
C�digo fonte